package Fibble::Bar;

use strict;
use warnings;
use CPANPLUS 99999;
use vars qw($VERSION);

$VERSION = '0.01';

'Foo Bar!'

__END__
